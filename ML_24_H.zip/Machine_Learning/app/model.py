import joblib

def load_model(path):
    return joblib.load(path)

def predict(model, features):
    # Features format is OK
    return model.predict([features])[0]

