from flask import Blueprint, render_template, request, jsonify
from app.model import load_model, predict

# BluePrint to set the routes
main = Blueprint('main', __name__)

# Load Model
model = load_model('models/svc_model.pkl')

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/predict', methods=['POST'])
def predict_route():
    data = request.json if request.is_json else request.form
   
    # Extract features
    features = [
        data.get('vehicle'),
        data.get('race'),
        data.get('event_duration'),
        data.get('season'),
        data.get('driver_1'),
        data.get('driver_2'),
        data.get('driver_3'),
        data.get('Competitor1'),
        data.get('Competitor1_Vehicle'),
        data.get('Competitor2'),
        data.get('Competitor2_Vehicle'),
        data.get('Season'),
        data.get('Environment'),
        data.get('Difficulty of Turning'),
        data.get('Straight Length'),
        data.get('Most Useful Attribute'),
        data.get('Second Most Useful Attribute'),
        data.get('Rain during the Race'),
        data.get('Max_Speed_Gap_Vs_Competitor_1'),
        data.get('Max_Speed_Gap_Vs_Competitor_2'),
        data.get('Min_Time_Gap_Vs_Competitor_1'),
        data.get('Min_Time_Gap_Vs_Competitor_2')
    ]
   
    # Predict
    prediction = predict(model, features)
   
    # Return the prediction
    return jsonify({'prediction': prediction})
